import React, { useEffect, useState, useMemo } from 'react'; // 👉 BƯỚC 1: Import thêm useMemo
import { RefreshCw, Filter, MousePointerClick, Users, Percent, AlertCircle, Globe, TrendingUp } from 'lucide-react';
import { BarChart, Bar, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

import { fetchMarketingReport, fetchMarketingMetaOptions, fetchChartStats, type MarketingReportResponse, type MarketingMetaOptions, type ChartStatsResponse } from '../adminApi';
import { useSiteContext } from '../../../../ula-chinese/context/LandingSiteContext';
import { adminCard, adminAccentText, adminSecondaryButton } from '../adminTheme';

// 👉 BƯỚC 4: Tạo Custom Hook useDebounce để chặn Spam API
function useDebounce<T>(value: T, delay: number): T {
  const [debouncedValue, setDebouncedValue] = useState<T>(value);
  useEffect(() => {
    const handler = setTimeout(() => { setDebouncedValue(value); }, delay);
    return () => clearTimeout(handler);
  }, [value, delay]);
  return debouncedValue;
}

export default function Overview() {
  const { siteKey } = useSiteContext();
  
  const [report, setReport] = useState<MarketingReportResponse | null>(null);
  const [metaOptions, setMetaOptions] = useState<MarketingMetaOptions | null>(null);
  const [chartDataAPI, setChartDataAPI] = useState<ChartStatsResponse | null>(null);
  
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');

  const isGerman = siteKey === 'tieng-duc';
  const siteName = isGerman ? 'Tiếng Đức (DE)' : 'Tiếng Trung (CN)';

  const [filters, setFilters] = useState({
    from: '',
    to: '',
    utm_source: '',
    utm_medium: '',
    tag: ''
  });

  // 👉 BƯỚC 4: Bọc filters qua một lớp trễ 500ms
  const debouncedFilters = useDebounce(filters, 500);

  // Hàm gọi API lõi (Có nhận biến isCancelled để trị bệnh Race Condition)
  const fetchDashboardData = async (activeFilters: Record<string, string>, isCancelled: boolean = false) => {
    setIsLoading(true);
    setError('');
    
    try {
      // 👉 BƯỚC 2: TRỊ BỆNH CHẾT CHÙM BẰNG Promise.allSettled
      const results = await Promise.allSettled([
        fetchMarketingReport(siteKey, activeFilters),
        fetchMarketingMetaOptions(siteKey),
        fetchChartStats(siteKey, activeFilters) // Nếu API Chart lỗi 404, 2 API trên vẫn sống
      ]);

      // 👉 BƯỚC 3: TRỊ RACE CONDITION - Chỉ cập nhật UI nếu chưa bị hủy
      if (isCancelled) return;

      // Xử lý API 1: Báo cáo bảng
      if (results[0].status === 'fulfilled') {
        setReport(results[0].value);
      } else {
        setError('Không tải được bảng báo cáo. ');
      }

      // Xử lý API 2: Meta Options (Bộ lọc)
      if (results[1].status === 'fulfilled') {
        setMetaOptions(results[1].value);
      }

      // Xử lý API 3: Biểu đồ
      if (results[2].status === 'fulfilled') {
        setChartDataAPI(results[2].value);
      } else {
        setChartDataAPI(null); // Nếu lỗi thì cho thành null để ẩn biểu đồ đi, không sập web
      }

    } catch (err: any) {
      if (!isCancelled) setError('Đã có lỗi hệ thống xảy ra.');
    } finally {
      if (!isCancelled) setIsLoading(false);
    }
  };

  // 👉 BƯỚC 3 & 4: Lắng nghe sự thay đổi của siteKey và debouncedFilters
  useEffect(() => {
    let isCancelled = false; // Cờ theo dõi vòng đời

    const activeFilters: Record<string, string> = {};
    Object.entries(debouncedFilters).forEach(([key, value]) => {
      if (value) activeFilters[key] = value;
    });

    void fetchDashboardData(activeFilters, isCancelled);

    // Hàm Cleanup: Bật cờ hủy khi component re-render hoặc unmount
    return () => { isCancelled = true; };
    
    // Ép object thành chuỗi JSON để so sánh, tránh re-render vô tận do khác tham chiếu bộ nhớ
  }, [siteKey, JSON.stringify(debouncedFilters)]);

  // Hàm dành riêng cho nút "Làm mới" (Không bị trễ)
  const handleManualRefresh = () => {
    const activeFilters: Record<string, string> = {};
    Object.entries(filters).forEach(([key, value]) => {
      if (value) activeFilters[key] = value;
    });
    void fetchDashboardData(activeFilters, false);
  };

  const clearFilters = () => {
    setFilters({ from: '', to: '', utm_source: '', utm_medium: '', tag: '' });
  };

  // 👉 BƯỚC 1: TRỊ BỆNH SẬP REACT TREE & TỐI ƯU RENDER (useMemo & ?.)
  const mappedChartData = useMemo(() => {
    if (!chartDataAPI?.labels) return [];
    
    return chartDataAPI.labels.map((label, index) => ({
      name: label,
      Clicks: chartDataAPI.datasets?.clicks?.[index] ?? 0,
      Leads:  chartDataAPI.datasets?.leads?.[index] ?? 0,
      CR:     chartDataAPI.datasets?.cr?.[index] ?? 0,
    }));
  }, [chartDataAPI]);

  return (
    <div className="space-y-8 animate-in fade-in duration-700 pb-20">
      
      {/* --- HEADER --- */}
      <div className="flex flex-wrap items-start justify-between gap-6">
        <div>
          <div className="flex items-center gap-2 text-[10px] uppercase tracking-[0.4em] font-black text-slate-500 mb-2">
            <Globe className="w-3 h-3 text-indigo-500" />
            Báo Cáo Tổng Hợp ({siteName})
          </div>
          <h2 className="text-3xl font-black text-black tracking-tight">Báo cáo <span className={adminAccentText}>Marketing</span></h2>
          <p className="mt-1 text-sm font-medium text-slate-500">Phân tích hiệu suất quảng cáo & Tỉ lệ chuyển đổi (CR).</p>
        </div>
        <button onClick={handleManualRefresh} className={adminSecondaryButton}>
          <RefreshCw className={`h-4 w-4 ${isLoading ? 'animate-spin' : ''}`} /> Đồng bộ
        </button>
      </div>

      {error && (
        <div className="rounded-2xl border border-rose-500/20 bg-rose-500/10 p-5 flex items-center gap-4 text-rose-400 font-bold text-sm">
          <AlertCircle className="h-5 w-5" /> {error}
        </div>
      )}

      {/* --- BỘ LỌC ĐA NĂNG --- */}
      <div className="p-6 bg-slate-50/80 rounded-[24px] border border-slate-100">
        <div className="flex items-center gap-2 text-slate-500 mb-4">
          <Filter className="w-4 h-4 text-indigo-500" />
          <span className="text-xs font-black uppercase tracking-widest text-slate-800">Lọc Báo Cáo</span>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3 items-end">
          <div className="col-span-2 lg:col-span-2 flex gap-2">
            <div className="flex-1">
              <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5 ml-1">Từ ngày</label>
              <input type="date" value={filters.from} onChange={(e) => setFilters(p => ({ ...p, from: e.target.value }))} className="w-full px-3 py-2 text-xs font-bold text-slate-700 bg-white border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500/20" />
            </div>
            <div className="flex-1">
              <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5 ml-1">Đến ngày</label>
              <input type="date" value={filters.to} onChange={(e) => setFilters(p => ({ ...p, to: e.target.value }))} className="w-full px-3 py-2 text-xs font-bold text-slate-700 bg-white border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500/20" />
            </div>
          </div>

          <div className="col-span-1">
            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5 ml-1">Nguồn (Source)</label>
            <select value={filters.utm_source} onChange={(e) => setFilters(p => ({ ...p, utm_source: e.target.value }))} className="w-full px-3 py-2 text-xs font-bold text-slate-700 bg-white border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500/20">
              <option value="">Tất cả</option>
              {metaOptions?.utmSources.map(s => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>

          <div className="col-span-1">
            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5 ml-1">Phương thức</label>
            <select value={filters.utm_medium} onChange={(e) => setFilters(p => ({ ...p, utm_medium: e.target.value }))} className="w-full px-3 py-2 text-xs font-bold text-slate-700 bg-white border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500/20">
              <option value="">Tất cả</option>
              {metaOptions?.utmMediums.map(m => <option key={m} value={m}>{m}</option>)}
            </select>
          </div>

          <div className="col-span-1">
            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5 ml-1">Chiến dịch</label>
            <select value={filters.tag} onChange={(e) => setFilters(p => ({ ...p, tag: e.target.value }))} className="w-full px-3 py-2 text-xs font-bold text-slate-700 bg-white border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500/20 truncate">
              <option value="">Tất cả</option>
              {metaOptions?.campaigns.map(c => <option key={c.value} value={c.value}>{c.label}</option>)}
            </select>
          </div>

          <div className="col-span-1">
             <button onClick={clearFilters} className="h-[34px] w-full flex items-center justify-center rounded-xl bg-slate-200/50 text-slate-500 hover:bg-rose-100 hover:text-rose-600 transition-colors text-xs font-bold">Xóa lọc</button>
          </div>
        </div>
      </div>

      {/* --- THẺ SUMMARY TỔNG QUAN --- */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className={adminCard}>
          <div className="flex items-center gap-4">
            <div className="h-12 w-12 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center shadow-sm"><MousePointerClick className="w-6 h-6" /></div>
            <div>
              <div className="text-[10px] uppercase font-black tracking-[0.2em] text-slate-400 mb-1">Tổng truy cập (Clicks)</div>
              <div className="text-3xl font-black text-slate-900">{report?.summary?.totalVisits || 0}</div>
            </div>
          </div>
        </div>

        <div className={adminCard}>
          <div className="flex items-center gap-4">
            <div className="h-12 w-12 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center shadow-sm"><Users className="w-6 h-6" /></div>
            <div>
              <div className="text-[10px] uppercase font-black tracking-[0.2em] text-slate-400 mb-1">Tổng đăng ký (Leads)</div>
              <div className="text-3xl font-black text-slate-900">{report?.summary?.totalLeads || 0}</div>
            </div>
          </div>
        </div>

        <div className={adminCard}>
          <div className="flex items-center gap-4">
            <div className="h-12 w-12 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center shadow-sm"><Percent className="w-6 h-6" /></div>
            <div>
              <div className="text-[10px] uppercase font-black tracking-[0.2em] text-slate-400 mb-1">Tỉ lệ chuyển đổi (CR)</div>
              <div className="text-3xl font-black text-amber-500">{report?.summary?.totalCR || "0%"}</div>
            </div>
          </div>
        </div>
      </div>

      {/* CÁC BIỂU ĐỒ TRỰC QUAN */}
      {mappedChartData.length > 0 && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <section className={`${adminCard} flex flex-col`}>
            <div className="mb-6">
              <h3 className="text-lg font-black text-slate-800 tracking-tight flex items-center gap-2">
                <MousePointerClick className="w-5 h-5 text-blue-500" /> Số lượng truy cập (Clicks)
              </h3>
            </div>
            <div className="h-[300px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={mappedChartData} margin={{ top: 20, right: 10, left: -20, bottom: 40 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#64748b', fontWeight: 600 }} angle={-35} textAnchor="end" />
                  <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#64748b' }} />
                  <Tooltip cursor={{ fill: '#f8fafc' }} contentStyle={{ borderRadius: '12px', border: 'none' }} />
                  <Bar dataKey="Clicks" name="Lượt Click" fill="#3b82f6" radius={[4, 4, 0, 0]} maxBarSize={40} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </section>

          <section className={`${adminCard} flex flex-col`}>
            <div className="mb-6">
              <h3 className="text-lg font-black text-slate-800 tracking-tight flex items-center gap-2">
                <Users className="w-5 h-5 text-emerald-500" /> Số lượng đăng ký (Leads)
              </h3>
            </div>
            <div className="h-[300px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={mappedChartData} margin={{ top: 20, right: 10, left: -20, bottom: 40 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#64748b', fontWeight: 600 }} angle={-35} textAnchor="end" />
                  <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#64748b' }} />
                  <Tooltip cursor={{ fill: '#f8fafc' }} contentStyle={{ borderRadius: '12px', border: 'none' }} />
                  <Bar dataKey="Leads" name="Số Lead" fill="#10b981" radius={[4, 4, 0, 0]} maxBarSize={40} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </section>

          <section className={`${adminCard} lg:col-span-2`}>
            <div className="mb-6">
              <h3 className="text-lg font-black text-slate-800 tracking-tight flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-amber-500" /> Tỷ lệ chuyển đổi (CR %)
              </h3>
            </div>
            <div className="h-[300px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={mappedChartData} margin={{ top: 20, right: 20, left: -20, bottom: 40 }}>
                  <defs>
                    <linearGradient id="colorCR" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#f59e0b" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#64748b', fontWeight: 600 }} angle={-25} textAnchor="end" />
                  <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#64748b' }} tickFormatter={(val) => `${val}%`} />
                  <Tooltip formatter={(value: number) => [`${value}%`, 'Tỷ lệ CR']} />
                  <Area type="monotone" dataKey="CR" name="Tỷ lệ CR (%)" stroke="#f59e0b" strokeWidth={3} fillOpacity={1} fill="url(#colorCR)" activeDot={{ r: 6, strokeWidth: 0, fill: '#f59e0b' }} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </section>
        </div>
      )}

      {/* --- BẢNG CHI TIẾT --- */}
      <section className={adminCard}>
        <div className="mb-6">
          <h3 className="text-lg font-black text-slate-800 tracking-tight">Chi Tiết Từng Chiến Dịch</h3>
        </div>
        <div className="relative overflow-hidden rounded-[32px] border border-slate-200 bg-white shadow-xl">
          <div className="overflow-x-auto no-scrollbar">
            <table className="min-w-full text-left text-sm border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-[10px] uppercase font-black tracking-[0.25em] text-slate-400">
                  <th className="px-6 py-5">Nguồn / Kênh (Source & Medium)</th>
                  <th className="px-6 py-5">Chiến dịch / Mã KOC</th>
                  <th className="px-6 py-5 text-center">Lượt bấm (Clicks)</th>
                  <th className="px-6 py-5 text-center">Đăng ký (Leads)</th>
                  <th className="px-6 py-5 text-right">Tỉ lệ CR</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {isLoading ? (
                  <tr><td colSpan={5} className="px-6 py-12 text-center"><RefreshCw className="w-6 h-6 text-indigo-500 animate-spin mx-auto" /></td></tr>
                ) : !report?.data || report.data.length === 0 ? (
                  <tr><td colSpan={5} className="px-6 py-12 text-center text-slate-400 font-bold italic">Không có dữ liệu báo cáo nào.</td></tr>
                ) : (
                  report.data.map((row, idx) => (
                    <tr key={idx} className="hover:bg-slate-50 transition-colors">
                      <td className="px-6 py-6">
                        <div className="flex flex-col gap-1.5">
                          <span className="text-xs font-black uppercase text-indigo-600">{row.source || "Tự nhiên"}</span>
                          <span className="text-[10px] font-bold text-slate-500">{row.medium || "Không xác định"}</span>
                        </div>
                      </td>
                      <td className="px-6 py-6">
                        <div className="flex flex-col gap-1.5">
                          <span className="text-xs font-black text-slate-800">{row.campaign || "Mặc định"}</span>
                          <span className="text-[10px] font-bold text-slate-500">Ref: {row.ref || "N/A"}</span>
                        </div>
                      </td>
                      <td className="px-6 py-6 text-center font-bold text-slate-700">{row.clicks}</td>
                      <td className="px-6 py-6 text-center font-bold text-emerald-600">{row.leads}</td>
                      <td className="px-6 py-6 text-right font-black text-amber-500">{row.cr}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </section>
      
    </div>
  );
}