export type EditorStatus = 'draft' | 'review' | 'published';

export interface HeroContent {
  badge: string;
  headlineTop: string;
  headlineHighlight: string;
  headlineBottom: string;
  description: string;
  primaryCta: string;
  secondaryCta: string;
  heroVideoWatchUrl: string;
  heroImageUrl?: string | File;
}

export const PAINPOINTS_DEFAULT_COUNT = 7;

export interface PainpointsContent {
  sectionTitle: string;
  mascotImageUrl: string;
  bubbles: string[];
}

export interface SolutionFeature {
  category: string;
  title: string;
  bullets: string[];
  mediaUrl: string | File;
  isVideo: boolean;
  gradient: string;
}

export interface SolutionContent {
  titlePart1: string;
  titleHighlight: string;
  titlePart2: string;
  cards: SolutionFeature[];
}

export interface MethodologyCard {
  number: string;
  title: string;
  subTitle: string;
  imgSrc: string | File;
}

export interface MethodologyContent {
  mainCard: MethodologyCard;
  cards: MethodologyCard[];
}

export interface ExperienceQuizOption {
  id: string;
  text: string;
}

export interface ExperienceQuizPair {
  de: string;
  vi: string;
  color?: string;
}

export interface ExperienceQuiz {
  id: number;
  word?: string;
  correctAnswer?: string;
  explanation?: string;
  options?: ExperienceQuizOption[];
  imageUrl?: string;
  type?: 'matching';
  pairs?: ExperienceQuizPair[];
}

export interface ExperienceContent {
  sectionTitle: string;
  sectionSubtitle: string;
  aiPronunciationImageUrl: string | File;
  videoUrl: string;
  quizzes: ExperienceQuiz[];
}

export interface LuckyWheelPrize {
  option: string;
  backgroundColor: string;
  textColor: string;
  code: string;
  probability?: number;
}

export const heroDefault: HeroContent = {
  badge: 'GIẢI PHÁP HỌC TIẾNG ĐỨC 5.0',
  headlineTop: 'HỌC TIẾNG ĐỨC TỪ SỚM',
  headlineHighlight: 'KHÔNG CẦN GIỎI',
  headlineBottom: 'CHỈ CẦN ĐÚNG CÁCH',
  description:
    'Học tiếng Đức thông minh cùng AI. Chỉ 30p/ngày tại nhà với video bài giảng + AI sửa phát âm + lộ trình rõ từng ngày.',
  primaryCta: 'Học thử miễn phí',
  secondaryCta: 'Nhận tư vấn lộ trình',
  heroVideoWatchUrl:
    'https://player.vimeo.com/manage/videos/1176153399/09b018576d',
  heroImageUrl: '/assets/images/hero-thumbnail.png',
};

export const painpointsDefault: PainpointsContent = {
  sectionTitle: 'ULA HIỂU NỖI LO CỦA PHỤ HUYNH VÀ HỌC SINH',
  sectionSubtitle: '',
  mainTitleTop: '',
  mainTitleHighlight: '',
  mascotImageUrl: '',
  bubbles: [
    'Lớp học offline đông',
    'Không gần trung tâm tiếng',
    'Muốn học sớm, phải chờ hết THPT',
    'Rủi ro chi phí 50tr - 100tr',
    'Đã sang Đức nhưng không nói được',
    'Tiếng Đức khó',
    'Học xong lại quên',
  ],
};

export const solutionDefault: SolutionContent = {
  titlePart1: 'Chỉ',
  titleHighlight: '30 phút/ngày',
  titlePart2: 'dễ dàng bắt đầu',
  cards: [
    {
      category: 'Coaching',
      title: 'Hiệu quả như gia sư 1 kèm 1',
      bullets: ['Video bài giảng cùng chuyên gia', 'Bắt đầu sớm từ lớp 10–11', 'Đội ngũ hỗ trợ 24/7'],
      mediaUrl: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?q=80&w=600',
      isVideo: false,
      gradient: 'from-indigo-600/40 to-blue-500/10',
    },
    {
      category: 'Practice',
      title: 'Luyện tập không giới hạn',
      bullets: ['Bài tập tương tác ngay trong video', 'AI luyện phát âm, phản xạ'],
      mediaUrl: 'https://images.unsplash.com/photo-1552664730-d307ca884978?q=80&w=600',
      isVideo: false,
      gradient: 'from-blue-400/20 to-white/5',
    },
    {
      category: 'Flexible',
      title: 'Học linh hoạt và tiết kiệm',
      bullets: ['Chỉ với 10k/ngày (giảm 80%)', 'Học mọi lúc với đa thiết bị'],
      mediaUrl: 'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?q=80&w=600',
      isVideo: false,
      gradient: 'from-blue-900/60 to-black/40',
    },
  ],
};

export const methodologyDefault: MethodologyContent = {
  mainCard: {
    number: 'Ô 1: AI CHẤM CHỮA',
    title: '03. AI CHẤM CHỮA',
    subTitle: '(Real-time Feedback)',
    imgSrc: 'https://images.unsplash.com/photo-1531482615713-2afd69097998?q=80&w=800',
  },
  cards: [
    {
      number: 'Ô 2: VIDEO',
      title: '01. BÀI GIẢNG',
      subTitle: 'Kiến thức cô đọng',
      imgSrc: 'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?q=80&w=400',
    },
    {
      number: 'Ô 3: BÀI TẬP',
      title: '02. TƯƠNG TÁC',
      subTitle: 'Thực hành ngay',
      imgSrc: 'https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?q=80&w=400',
    },
    {
      number: 'Ô 4: CÔNG CỤ',
      title: '04. FLASHCARDS',
      subTitle: 'Thuật toán lặp lại',
      imgSrc: 'https://images.unsplash.com/photo-1584697964400-2af6a2f6204c?q=80&w=400',
    },
    {
      number: 'Ô 5: LỘ TRÌNH',
      title: '05. TIẾN ĐỘ',
      subTitle: 'Theo dõi thông minh',
      imgSrc: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?q=80&w=400',
    },
  ],
};

export const experienceDefault: ExperienceContent = {
  sectionTitle: 'Trải nghiệm học tập',
  sectionSubtitle: 'Cùng AI chấm chữa',
  aiPronunciationImageUrl: 'https://media.istockphoto.com/id/1370433251/photo/black-woman-sitting-at-desk-using-computer-writing-in-notebook.jpg?s=612x612&w=0&k=20&c=rHpy3cX4LVFtzLI4gyy0T-fNYdTeAcdNQgTmy9maAIA=',
  videoUrl: 'https://player.vimeo.com/video/1163868662?h=2e449d303e',
  quizzes: [
    {
      id: 1,
      word: 'Hallo!',
      correctAnswer: 'B',
      explanation: 'Hallo có nghĩa là Xin chào trong tiếng Đức.',
      options: [
        { id: 'A', text: 'Tạm biệt' },
        { id: 'B', text: 'Xin chào' },
        { id: 'C', text: 'Cảm ơn' },
      ],
      imageUrl: 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?q=80&w=800',
    },
    {
      id: 2,
      word: "Nối từ: 'Danke' tương ứng với?",
      correctAnswer: 'C',
      explanation: "'Danke' trong tiếng Đức là lời cảm ơn lịch sự.",
      options: [
        { id: 'A', text: 'Chào buổi sáng' },
        { id: 'B', text: 'Chúc ngủ ngon' },
        { id: 'C', text: 'Cảm ơn bạn' },
      ],
      imageUrl: "https://media.istockphoto.com/id/1225960444/photo/friends-clinking-glasses-of-beer.jpg?s=612x612&w=0&k=20&c=F5y3l0C0b2N5_hS0Y7sP6YJ5_Q9ZcR0V_u8tP6_pL4k="
    },
    {
      id: 3,
      word: "Điền nghĩa: 'Tschüss' có nghĩa là...",
      correctAnswer: 'A',
      explanation: "'Tschüss' là cách chào tạm biệt phổ biến nhất trong đời sống hàng ngày.",
      options: [
        { id: 'A', text: 'Tạm biệt' },
        { id: 'B', text: 'Hẹn gặp lại' },
        { id: 'C', text: 'Rất vui được gặp' },
      ],
      imageUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=800',
    },
    {
      id: 4,
      type: 'matching',
      pairs: [
        { de: 'Hallo', vi: 'Xin chào', color: '#3b82f6' },
        { de: 'Danke', vi: 'Cảm ơn', color: '#8b5cf6' },
        { de: 'Tschüss', vi: 'Tạm biệt', color: '#ec4899' },
        { de: 'Bier', vi: 'Bia', color: '#f59e0b' },
      ],
    },
  ],
};

export const luckyWheelDefault: LuckyWheelPrize[] = [
  { option: 'Voucher 10%', backgroundColor: '#2563eb', textColor: 'white', code: 'ULA-VOUCHER10', probability: 1 },
  { option: 'Khóa học FREE', backgroundColor: '#004ac6', textColor: 'white', code: 'ULA-FREECOURSE', probability: 1 },
  { option: 'Bút ký ULA', backgroundColor: '#ba0a0d', textColor: 'white', code: 'ULA-PEN', probability: 1 },
  { option: 'Sổ tay Đức', backgroundColor: '#e63329', textColor: 'white', code: 'ULA-NOTEBOOK', probability: 1 },
  { option: 'Chúc bạn may mắn', backgroundColor: '#f5a623', textColor: 'black', code: 'ULA-LUCK', probability: 1 },
  { option: 'Tài liệu A1', backgroundColor: '#ffddb4', textColor: 'black', code: 'ULA-DOCS', probability: 1 },
];
